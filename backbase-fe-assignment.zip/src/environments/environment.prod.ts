export const environment = {
  production: true,
  api_url: "",
  transactions: "http://localhost:8000/assets/mocks/transactions.json"
};
