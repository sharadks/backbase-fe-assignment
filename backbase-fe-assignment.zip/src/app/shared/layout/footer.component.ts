import { Component, Output } from "@angular/core";
import { Subject } from "rxjs/Subject";

@Component({
  selector: "layout-footer",
  templateUrl: "./footer.component.html"
})
export class FooterComponent {
  constructor() {}
}
